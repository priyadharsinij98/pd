import java.sql.*;
public class LValidate {
    public static boolean checkUser(String email,String pass) 
    {
        boolean st =false;
        try {
            Class.forName("org.h2.Driver");
            Connection con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test/student","sa","");
            PreparedStatement ps = con.prepareStatement("select * from registration where email=? and pass=?");
            ps.setString(1, email);
            ps.setString(2, pass);
            ResultSet rs =ps.executeQuery();
            st = rs.next();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return st;                 
    }   
}