import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class UpdateValidate extends HttpServlet {
     private static final long serialVersionUID = 1L; 
     @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { 
       try{  
        Connection conn =  H2jdbc.initializeDatabase(); 
            PreparedStatement st = conn.prepareStatement("insert into Updation values(?,?,?,?,?,?,?,?,?)");
              st.setString(1, request.getParameter("name")); 
              st.setString(2, request.getParameter("qualification"));
              st.setString(3, request.getParameter("stream"));
              st.setString(4, request.getParameter("skill1"));
              st.setString(5, request.getParameter("skill2"));
              st.setString(6, request.getParameter("skill3"));  
              st.setString(6, request.getParameter("yof"));
              st.setString(6, request.getParameter("experience"));
              st.setString(6, request.getParameter("percentage"));
              st.setString(6, request.getParameter(""));
              st.executeUpdate(); 
            st.close(); 
            conn.close(); 
            PrintWriter out = response.getWriter(); 
            out.println("<html><body><b>Successfully Inserted"
                        + "</b></body></html>"); 
             response.sendRedirect("Login.jsp");
        } 
        catch (Exception e) 
        { 
            e.printStackTrace(); 
        } 
        } 
      }     