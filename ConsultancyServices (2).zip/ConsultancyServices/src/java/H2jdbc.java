import java.sql.Connection; 
import java.sql.DriverManager;
import java.sql.SQLException; 


public class H2jdbc { 
    protected static Connection initializeDatabase() 
        throws SQLException, ClassNotFoundException 
    {
    String dbDriver = "org.h2.Driver";   
    String dbURL = "jdbc:h2:tcp://localhost/~/test/student";  
    String dbUsername = "sa"; 
    String dbPassword = ""; 
     
        Class.forName(dbDriver); 
        Connection con = DriverManager.getConnection(dbURL,
                                                     dbUsername,  
                                                     dbPassword); 
        return con; 
    } 
} 